-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mar 04, 2026 alle 19:30
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aura_essenza`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `composizione`
--

CREATE TABLE `composizione` (
  `id` int(11) NOT NULL,
  `id_formulazione` int(11) NOT NULL,
  `id_essenza` int(11) NOT NULL,
  `quantita_grammi` decimal(10,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `composizione`
--

INSERT INTO `composizione` (`id`, `id_formulazione`, `id_essenza`, `quantita_grammi`) VALUES
(14, 9, 5, 200.000),
(15, 9, 8, 50.000),
(16, 9, 9, 50.000),
(18, 9, 12, 10.000),
(19, 10, 1, 500.000),
(20, 10, 8, 30.000),
(21, 10, 7, 10.000),
(22, 11, 8, 500.000),
(23, 11, 5, 80.000),
(24, 11, 7, 100.000),
(25, 11, 2, 30.000),
(26, 12, 9, 500.000),
(27, 12, 10, 60.000),
(28, 12, 4, 100.000);

-- --------------------------------------------------------

--
-- Struttura della tabella `essenze`
--

CREATE TABLE `essenze` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `famiglia` enum('fiorita','legnosa','orientale','fresca') DEFAULT NULL,
  `quantita_g` decimal(10,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `essenze`
--

INSERT INTO `essenze` (`id`, `nome`, `famiglia`, `quantita_g`) VALUES
(1, 'Bergamotto', 'fresca', 685.000),
(2, 'Rosa', 'fiorita', 750.000),
(3, 'Cedro', 'legnosa', 1000.000),
(4, 'Vaniglia', 'orientale', 900.000),
(5, 'Gelsomino', 'fiorita', 1920.000),
(6, 'Lavanda', 'fiorita', 2000.000),
(7, 'Sandalo', 'legnosa', 1900.000),
(8, 'Patchouli', 'legnosa', 1450.000),
(9, 'Ambra', 'orientale', 1500.000),
(10, 'Cannella', 'orientale', 1940.000),
(11, 'Limone', 'fresca', 1900.000),
(12, 'Menta', 'fresca', 2000.000);

-- --------------------------------------------------------

--
-- Struttura della tabella `formulazioni`
--

CREATE TABLE `formulazioni` (
  `id` int(11) NOT NULL,
  `nome_profumo` varchar(100) DEFAULT NULL,
  `id_naso` int(11) DEFAULT NULL,
  `stato_test` enum('in_attesa','superato','fallito') DEFAULT 'in_attesa',
  `famiglia` varchar(50) DEFAULT NULL,
  `stato` varchar(20) DEFAULT 'in_lavorazione'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `formulazioni`
--

INSERT INTO `formulazioni` (`id`, `nome_profumo`, `id_naso`, `stato_test`, `famiglia`, `stato`) VALUES
(9, 'Notturno di Gelsomino', 26, 'in_attesa', 'fiorita', 'test_in_corso'),
(10, 'Raggio di Bergamotto', 24, 'in_attesa', 'fresca', 'test_in_corso'),
(11, 'Radici Profonde', 25, 'in_attesa', 'legnosa', 'in_lavorazione'),
(12, 'Notte d’Oriente', 23, 'in_attesa', 'orientale', 'in_lavorazione');

-- --------------------------------------------------------

--
-- Struttura della tabella `nasi`
--

CREATE TABLE `nasi` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `specializzazione` varchar(100) DEFAULT NULL,
  `data_assunzione` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `nasi`
--

INSERT INTO `nasi` (`id`, `nome`, `cognome`, `specializzazione`, `data_assunzione`) VALUES
(21, 'Riccardo', 'Del Gaudio', 'Controllo Qualità', '2026-03-03'),
(22, 'Ilaria', 'Porcelli', 'Magazziniere', '2026-03-03'),
(23, 'Gabriele', 'Zica', 'Esperto Note Orientali', '2026-03-03'),
(24, 'Vincenzo', 'Petrazzuolo', 'Esperto Note Fresche', '2026-03-03'),
(25, 'Francesco', 'Iorio', 'Esperto Note Legnose', '2026-03-03'),
(26, 'Paolo', 'Fiorenzo', 'Esperto Note Floreali', '2026-03-03'),
(99999, 'admin', 'utente', 'Admin', '2026-03-04');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `ruolo` enum('admin','controllo_qualita','esperto','magazziniere') NOT NULL,
  `id_naso` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `username`, `password`, `ruolo`, `id_naso`) VALUES
(1, '', '$2y$10$hnev4K0pM5RgclW8/idb8.67mnnZlxeTbktXrgk5zCTBqkQ9Lf/4S', 'admin', 99999),
(25599, '', '$2y$10$veluYAE8jNBBOiYgLOYsQOCoeI79tFkE/q5MnOBn5zZGzwV3hvf9m', 'esperto', 23),
(33152, '', '$2y$10$yjDSeREzJbqYgqJREfpXke7MyGtqleVWw8BEKrR4FkFPbFwjQFhl6', 'esperto', 25),
(46200, '', '$2y$10$Ezv6dQkrQ0SMkCj8qEp/Y.ZZ3Iq43KT1pWidjdNBAAGmxcqwuzp9y', 'controllo_qualita', 21),
(64445, '', '$2y$10$NLmELQqNAD.iWtzwojeG2.SM4uhIDO.XUT0StbnU9Y/t1nl.7GUVq', 'magazziniere', 22),
(85202, '', '$2y$10$M93/vrWDpT9.ypcCUUYlBuMRs887nqdoyK9dTIBjmy97SuO6XonAq', 'esperto', 24),
(86954, '', '$2y$10$ZKGqM3pLsJXsVoAlwlVwpOWIajTYV4LNMjcm84IWAyc7wXnsiWssC', 'esperto', 26);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `composizione`
--
ALTER TABLE `composizione`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_formulazione` (`id_formulazione`),
  ADD KEY `id_essenza` (`id_essenza`);

--
-- Indici per le tabelle `essenze`
--
ALTER TABLE `essenze`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `formulazioni`
--
ALTER TABLE `formulazioni`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `nasi`
--
ALTER TABLE `nasi`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_naso` (`id_naso`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `composizione`
--
ALTER TABLE `composizione`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT per la tabella `essenze`
--
ALTER TABLE `essenze`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT per la tabella `formulazioni`
--
ALTER TABLE `formulazioni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT per la tabella `nasi`
--
ALTER TABLE `nasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100000;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86956;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `composizione`
--
ALTER TABLE `composizione`
  ADD CONSTRAINT `composizione_ibfk_1` FOREIGN KEY (`id_formulazione`) REFERENCES `formulazioni` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `composizione_ibfk_2` FOREIGN KEY (`id_essenza`) REFERENCES `essenze` (`id`);

--
-- Limiti per la tabella `utenti`
--
ALTER TABLE `utenti`
  ADD CONSTRAINT `utenti_ibfk_1` FOREIGN KEY (`id_naso`) REFERENCES `nasi` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
